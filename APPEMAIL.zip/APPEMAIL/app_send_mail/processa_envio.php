<?php
    
    //requisição do arquivo protegido
    require "../../app_send_mail/processa_envio.php";

    //Como o PHPMailer é publico pode ficar tranquilo, mas se usar outra biblioteca sigilosa deve proteger o arquivo também e requerer!

?>